<?php
/**
 * Plugin Name: GNB Mentor Pay Gateway for WooCommerce
 * Plugin URI: https://gnbmentor.com
 * Description: Connects WooCommerce with pay.gnbmentor.com for Google Pay and Stripe live processing.
 * Version: 2.1.0
 * Author: GNB Mentor Team
 * Text Domain: gnbmentor-pay
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'gnbmentor_pay_init_gateway');

function gnbmentor_pay_init_gateway() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Gateway_GNBMentor_Pay extends WC_Payment_Gateway {
        public $pay_portal_url;
        public $hmac_secret;

        public function __construct() {
            $this->id                 = 'gnbmentor_pay';
            $this->icon               = 'https://pay.google.com/about/static/images/logos/google-pay-logo.svg';
            $this->has_fields         = false;
            $this->method_title       = __('Google Pay & Cards (pay.gnbmentor.com)', 'gnbmentor-pay');
            $this->method_description = __('Redirects customers to pay.gnbmentor.com for secure Google Pay and Stripe checkout.', 'gnbmentor-pay');

            $this->init_form_fields();
            $this->init_settings();

            $this->title          = $this->get_option('title', 'Google Pay / Credit & Debit Card');
            $this->description    = $this->get_option('description', 'Pay quickly and securely with Google Pay or your credit/debit card.');
            $this->pay_portal_url = rtrim($this->get_option('pay_portal_url', 'https://pay.gnbmentor.com'), '/');
            $this->hmac_secret    = $this->get_option('hmac_secret', '');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('Enable/Disable', 'gnbmentor-pay'),
                    'type'    => 'checkbox',
                    'label'   => __('Enable GNB Mentor Pay Gateway', 'gnbmentor-pay'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __('Title', 'gnbmentor-pay'),
                    'type'        => 'text',
                    'description' => __('Payment method title displayed during checkout.', 'gnbmentor-pay'),
                    'default'     => __('Google Pay / Credit & Debit Card', 'gnbmentor-pay'),
                ),
                'description' => array(
                    'title'       => __('Description', 'gnbmentor-pay'),
                    'type'        => 'textarea',
                    'description' => __('Payment method description shown on checkout.', 'gnbmentor-pay'),
                    'default'     => __('Pay quickly and securely with Google Pay or your credit/debit card.', 'gnbmentor-pay'),
                ),
                'pay_portal_url' => array(
                    'title'       => __('Payment Portal URL', 'gnbmentor-pay'),
                    'type'        => 'text',
                    'description' => __('URL of your payment portal (e.g. https://pay.gnbmentor.com)', 'gnbmentor-pay'),
                    'default'     => 'https://pay.gnbmentor.com',
                ),
                'hmac_secret' => array(
                    'title'       => __('HMAC Shared Secret Key', 'gnbmentor-pay'),
                    'type'        => 'password',
                    'description' => __('Shared key matching HMAC_SECRET_KEY in your .env file on pay.gnbmentor.com. Leave empty to use secure default.', 'gnbmentor-pay'),
                    'default'     => '',
                ),
            );
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                return array('result' => 'fail');
            }

            $amount        = number_format((float)$order->get_total(), 2, '.', '');
            $currency      = strtoupper($order->get_currency());
            $timestamp     = time();
            $order_key     = $order->get_order_key();
            $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            $customer_email = $order->get_billing_email();

            $secret    = !empty($this->hmac_secret) ? $this->hmac_secret : 'gnbmentor_secure_default_secret_2026';
            $payload   = "{$order_id}|{$amount}|{$currency}|{$timestamp}";
            $signature = hash_hmac('sha256', $payload, $secret);

            $query_args = array(
                'order_id'       => $order_id,
                'amount'         => $amount,
                'currency'       => $currency,
                'order_key'      => $order_key,
                'customer_name'  => $customer_name,
                'customer_email' => $customer_email,
                'timestamp'      => $timestamp,
                'signature'      => $signature,
                'return_url'     => $this->get_return_url($order),
            );

            $redirect_url = add_query_arg($query_args, $this->pay_portal_url . '/checkout');

            $order->update_status('pending', __('Customer redirected to pay.gnbmentor.com for Google Pay & Card authorization', 'gnbmentor-pay'));

            return array(
                'result'   => 'success',
                'redirect' => $redirect_url,
            );
        }
    }

    add_filter('woocommerce_payment_gateways', function($gateways) {
        $gateways[] = 'WC_Gateway_GNBMentor_Pay';
        return $gateways;
    });
}

/**
 * 1. REST API Callback Handler for server-to-server notifications
 */
add_action('rest_api_init', function () {
    register_rest_route('gnbmentor-pay/v1', '/payment-callback', array(
        'methods'             => 'POST',
        'callback'            => 'gnbmentor_pay_callback_handler',
        'permission_callback' => '__return_true',
    ));
});

function gnbmentor_pay_callback_handler(WP_REST_Request $request) {
    $params = $request->get_json_params();

    if (empty($params['order_id']) || empty($params['transaction_id'])) {
        return new WP_Error('missing_params', 'Missing required order parameters', array('status' => 400));
    }

    $order_id       = absint($params['order_id']);
    $transaction_id = sanitize_text_field($params['transaction_id']);
    $order          = wc_get_order($order_id);

    if (!$order) {
        return new WP_Error('not_found', 'Order not found', array('status' => 404));
    }

    if (!$order->is_paid()) {
        $order->payment_complete($transaction_id);
        $order->add_order_note(sprintf('Payment verified via pay.gnbmentor.com (Stripe Transaction ID: %s)', $transaction_id));
        if (function_exists('wc_reduce_stock_levels')) {
            wc_reduce_stock_levels($order_id);
        }
    }

    return rest_ensure_response(array('success' => true, 'order_id' => $order_id));
}

/**
 * 2. Return URL Hook: Dual-channel verification on thank-you page
 * Ensures order is marked paid even if Cloudflare or firewall blocked background REST API
 */
add_action('woocommerce_thankyou', 'gnbmentor_pay_verify_thankyou_order', 10, 1);
function gnbmentor_pay_verify_thankyou_order($order_id) {
    if (!$order_id) {
        return;
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    $payment_status = isset($_GET['payment_status']) ? sanitize_text_field($_GET['payment_status']) : '';
    $transaction_id = isset($_GET['transaction_id']) ? sanitize_text_field($_GET['transaction_id']) : (isset($_GET['tx']) ? sanitize_text_field($_GET['tx']) : '');

    if ($payment_status === 'success' && !$order->is_paid()) {
        $tx_id = !empty($transaction_id) ? $transaction_id : 'gpay_live_' . time();
        $order->payment_complete($tx_id);
        $order->add_order_note(sprintf('Payment verified upon return from pay.gnbmentor.com (Stripe Transaction ID: %s)', $tx_id));
        if (function_exists('wc_reduce_stock_levels')) {
            wc_reduce_stock_levels($order_id);
        }
    }
}
