import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldCheck,
  Lock,
  CreditCard,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  RefreshCw,
  ShoppingBag,
  ExternalLink,
  HelpCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { OrderDetails, PaymentStatus } from '../types';
import { GooglePayButton } from './GooglePayButton';
import { SuccessState } from './SuccessState';
import { CardPreview } from './CardPreview';

interface CheckoutPortalProps {
  onOpenSimulator?: () => void;
}

export const CheckoutPortal: React.FC<CheckoutPortalProps> = ({ onOpenSimulator }) => {
  const [order, setOrder] = useState<OrderDetails | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activePaymentMethod, setActivePaymentMethod] = useState<'gpay' | 'card'>('gpay');
  const [transactionId, setTransactionId] = useState<string>('');

  // Card Form State
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [cardName, setCardName] = useState('');
  const [saveCard, setSaveCard] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Detect Card Brand from card number
  const detectedBrand = useMemo<'visa' | 'mastercard' | 'amex' | 'discover' | 'generic'>(() => {
    const clean = cardNumber.replace(/\D/g, '');
    if (clean.startsWith('4')) return 'visa';
    if (/^(5[1-5]|2[2-7])/.test(clean)) return 'mastercard';
    if (/^(34|37)/.test(clean)) return 'amex';
    if (/^(6011|65|64[4-9])/.test(clean)) return 'discover';
    return 'generic';
  }, [cardNumber]);

  // Parse URL search parameters on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const order_id = params.get('order_id');
    const amountStr = params.get('amount');
    const currency = params.get('currency') || 'USD';
    const customer_name = params.get('customer_name') || '';
    const customer_email = params.get('customer_email') || '';
    const order_key = params.get('order_key') || '';
    const timestampStr = params.get('timestamp');
    const signature = params.get('signature');
    const return_url = params.get('return_url') || '';

    if (order_id && amountStr) {
      const amount = parseFloat(amountStr);
      const parsedOrder: OrderDetails = {
        order_id,
        amount: isNaN(amount) ? 49.0 : amount,
        currency: currency.toUpperCase(),
        customer_name: customer_name || 'Valued Customer',
        customer_email: customer_email || '',
        order_key,
        timestamp: timestampStr ? parseInt(timestampStr, 10) : undefined,
        signature: signature || undefined,
        return_url: return_url || undefined,
      };

      setOrder(parsedOrder);
      if (customer_name) {
        setCardName(customer_name);
      }
      verifyOrderSignature(parsedOrder);
    } else {
      // Clean fallback demo order if accessed directly without parameters
      setOrder({
        order_id: '1084',
        amount: 49.0,
        currency: 'USD',
        customer_name: 'Alex Johnson',
        customer_email: 'alex@example.com',
        order_key: 'wc_order_demo',
        timestamp: Math.floor(Date.now() / 1000),
      });
      setCardName('Alex Johnson');
      setPaymentStatus('ready');
    }
  }, []);

  const verifyOrderSignature = async (orderData: OrderDetails) => {
    if (!orderData.signature || !orderData.timestamp) {
      setPaymentStatus('ready');
      return;
    }

    try {
      setPaymentStatus('validating');
      const response = await fetch('/api/verify-signature', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          order_id: orderData.order_id,
          amount: orderData.amount,
          currency: orderData.currency,
          timestamp: orderData.timestamp,
          signature: orderData.signature,
        }),
      });

      const result = await response.json();
      if (response.ok && result.valid) {
        setPaymentStatus('ready');
      } else {
        setPaymentStatus('signature_error');
        setErrorMessage(
          result.error ||
            'Payment link signature has expired or could not be verified. Please return to your cart.'
        );
      }
    } catch {
      setPaymentStatus('ready');
    }
  };

  // Google Pay Checkout Flow
  const handleGooglePayClick = async () => {
    if (!order) return;
    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          order_id: order.order_id,
          amount: order.amount,
          currency: order.currency,
          customer_name: order.customer_name,
          customer_email: order.customer_email,
          order_key: order.order_key,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to initialize Google Pay session');

      // Native authorization animation feel
      await new Promise((resolve) => setTimeout(resolve, 1400));

      const confirmedId = data.id || `gpay_${Date.now()}`;
      setTransactionId(confirmedId);

      // Trigger server webhook notification to update WooCommerce
      await fetch('/api/webhook/stripe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'payment_intent.succeeded',
          data: {
            object: {
              id: confirmedId,
              amount: Math.round(order.amount * 100),
              currency: order.currency.toLowerCase(),
              receipt_email: order.customer_email,
              metadata: {
                order_id: order.order_id,
                order_key: order.order_key,
                customer_name: order.customer_name,
              },
            },
          },
        }),
      });

      setPaymentStatus('succeeded');
    } catch (err: any) {
      setErrorMessage(err.message || 'Google Pay processing encountered an issue. Please try card checkout.');
      setPaymentStatus('failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // Credit / Debit Card Checkout Flow
  const handleCardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!order) return;

    if (!cardNumber || !cardExpiry || !cardCvc) {
      setErrorMessage('Please complete all card details to proceed.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          order_id: order.order_id,
          amount: order.amount,
          currency: order.currency,
          customer_name: cardName || order.customer_name,
          customer_email: order.customer_email,
          order_key: order.order_key,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Card payment authorization failed');

      // Authorization simulation
      await new Promise((resolve) => setTimeout(resolve, 1300));

      const confirmedId = data.id || `ch_${Date.now()}`;
      setTransactionId(confirmedId);

      // Trigger webhook callback to update WooCommerce status
      await fetch('/api/webhook/stripe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'payment_intent.succeeded',
          data: {
            object: {
              id: confirmedId,
              amount: Math.round(order.amount * 100),
              currency: order.currency.toLowerCase(),
              receipt_email: order.customer_email,
              metadata: {
                order_id: order.order_id,
                order_key: order.order_key,
              },
            },
          },
        }),
      });

      setPaymentStatus('succeeded');
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment authorization declined. Please verify your card information.');
      setPaymentStatus('failed');
    } finally {
      setIsProcessing(false);
    }
  };

  if (paymentStatus === 'succeeded' && order) {
    return (
      <SuccessState
        order={order}
        transactionId={transactionId}
        paymentMethod={activePaymentMethod === 'gpay' ? 'google_pay' : 'card'}
        onReset={() => {
          setPaymentStatus('ready');
          setErrorMessage(null);
        }}
      />
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Signature Error Notification */}
      {paymentStatus === 'signature_error' && (
        <div className="mb-8 p-4 sm:p-5 bg-amber-50/90 border border-amber-200/80 rounded-2xl text-amber-900 text-xs sm:text-sm flex items-start gap-3 shadow-xs">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold text-amber-950">Notice Regarding Checkout Session</h4>
            <p className="mt-1 text-amber-800 leading-relaxed">{errorMessage}</p>
            <div className="mt-3">
              <a
                href={order?.return_url || 'https://gnbmentor.com'}
                className="inline-flex items-center gap-1.5 font-semibold text-amber-950 hover:underline"
              >
                <span>Return to gnbmentor.com to re-open order</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Main 2-Column Luxury Split Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left Column: Order Overview, Reassurance & Breakdown */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-[0_4px_24px_rgba(15,23,42,0.04)] p-6 sm:p-7">
            {/* Order Ref & Status */}
            <div className="flex items-center justify-between pb-5 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Order Summary</h3>
                  <p className="text-[11px] text-slate-400">gnbmentor.com Checkout</p>
                </div>
              </div>
              <span className="font-mono text-xs font-semibold text-slate-700 bg-slate-100/80 px-2.5 py-1 rounded-lg border border-slate-200/50">
                #{order?.order_id || '---'}
              </span>
            </div>

            {/* Product Item Showcase */}
            <div className="py-5 border-b border-slate-100">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <h4 className="text-sm font-semibold text-slate-900 leading-snug">
                    Mentorship & Consultation Access
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Direct access session & materials from GNB Mentor
                  </p>
                  <div className="flex items-center gap-2 pt-1 text-[11px] text-emerald-700">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Instant activation upon payment</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-mono text-base font-bold text-slate-900 tabular-nums">
                    {order?.currency} {order?.amount.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Itemized Math Breakdown */}
            <div className="py-4 space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums font-medium text-slate-800">
                  {order?.currency} {order?.amount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Payment Processing</span>
                <span className="font-medium text-emerald-600">Free</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Tax & VAT</span>
                <span className="font-medium text-slate-500">Included</span>
              </div>
              <div className="pt-3 border-t border-slate-100 flex justify-between items-baseline">
                <div>
                  <span className="text-sm font-bold text-slate-900 block">Total Due</span>
                  <span className="text-[11px] text-slate-400">All fees included</span>
                </div>
                <div className="text-right">
                  <span className="font-mono text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight tabular-nums">
                    {order?.currency} {order?.amount.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Customer Contact Receipt Info */}
            {order?.customer_email && (
              <div className="mt-4 pt-4 border-t border-slate-100 bg-slate-50/70 -mx-6 -mb-6 p-6 rounded-b-3xl">
                <div className="text-xs space-y-1.5">
                  <div className="flex justify-between text-slate-500">
                    <span>Customer Name:</span>
                    <span className="font-semibold text-slate-800">{order.customer_name}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Confirmation Email:</span>
                    <span className="font-medium text-slate-800 truncate max-w-[200px]">
                      {order.customer_email}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Trust & Guarantee Box */}
          <div className="bg-slate-50/80 rounded-3xl border border-slate-200/70 p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Secure Payment Guaranteed</h4>
                <p className="text-[11px] text-slate-500">
                  Encrypted via TLS 1.3 protocol and Level-1 PCI DSS certified.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-200/50 text-[11px] text-slate-600">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Google Pay Verified</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Stripe Certified</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Zero Card Storage</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Instant Order Sync</span>
              </div>
            </div>

            <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-200/50">
              <span>Questions about this order?</span>
              <a
                href="mailto:support@gnbmentor.com"
                className="text-slate-700 font-semibold hover:underline"
              >
                support@gnbmentor.com
              </a>
            </div>
          </div>
        </div>

        {/* Right Column: High-Converting Payment Module */}
        <div className="lg:col-span-7">
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-[0_4px_24px_rgba(15,23,42,0.06)] p-6 sm:p-8">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                  Choose How to Pay
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Fast 1-click Google Pay or enter your debit / credit card
                </p>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200/60">
                <Lock className="w-3 h-3 text-emerald-600" />
                <span>256-bit SSL</span>
              </div>
            </div>

            {/* Payment Method Selector Tabs */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100/80 rounded-2xl mb-6">
              <button
                type="button"
                onClick={() => setActivePaymentMethod('gpay')}
                className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                  activePaymentMethod === 'gpay'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                {/* Mini GPay logo */}
                <svg className="h-3.5 w-auto" viewBox="0 0 41 17" fill="none">
                  <path
                    d="M19.5 8.6c0-.6-.1-1.2-.2-1.7H10v3.4h5.3c-.2 1.2-.9 2.2-2 2.8v2.3h3.2c1.9-1.7 3-4.3 3-6.8z"
                    fill="#4285F4"
                  />
                  <path
                    d="M10 17.5c2.7 0 5-1 6.7-2.6l-3.2-2.3c-.9.6-2 .9-3.5.9-2.7 0-5-1.8-5.8-4.3H.8v2.4C2.5 15.1 6 17.5 10 17.5z"
                    fill="#34A853"
                  />
                  <path
                    d="M4.2 9.2c-.2-.6-.3-1.4-.3-2.2 0-.8.1-1.6.3-2.2V2.4H.8C.1 3.8-.3 5.4-.3 7s.4 3.2 1.1 4.6l3.4-2.4z"
                    fill="#FBBC04"
                  />
                  <path
                    d="M10 3.8c1.5 0 2.8.5 3.9 1.5l2.9-2.9C15 1 12.7 0 10 0 6 0 2.5 2.4.8 5.8l3.4 2.4c.8-2.5 3.1-4.4 5.8-4.4z"
                    fill="#EA4335"
                  />
                </svg>
                <span>Google Pay</span>
              </button>

              <button
                type="button"
                onClick={() => setActivePaymentMethod('card')}
                className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                  activePaymentMethod === 'card'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                <CreditCard className="w-4 h-4 text-slate-700" />
                <span>Debit / Credit Card</span>
              </button>
            </div>

            {/* Error Message Alert */}
            {errorMessage && (
              <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs sm:text-sm flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <span className="font-semibold text-rose-950">Payment Alert</span>
                  <p className="mt-0.5 text-rose-800">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Google Pay Tab Content */}
            {activePaymentMethod === 'gpay' && (
              <div className="space-y-6">
                <div className="bg-slate-50/70 border border-slate-200/60 rounded-2xl p-5 text-center space-y-3">
                  <div className="w-12 h-12 bg-white rounded-full shadow-xs border border-slate-200/60 flex items-center justify-center mx-auto">
                    <svg className="h-6 w-auto" viewBox="0 0 41 17" fill="none">
                      <path
                        d="M19.5 8.6c0-.6-.1-1.2-.2-1.7H10v3.4h5.3c-.2 1.2-.9 2.2-2 2.8v2.3h3.2c1.9-1.7 3-4.3 3-6.8z"
                        fill="#4285F4"
                      />
                      <path
                        d="M10 17.5c2.7 0 5-1 6.7-2.6l-3.2-2.3c-.9.6-2 .9-3.5.9-2.7 0-5-1.8-5.8-4.3H.8v2.4C2.5 15.1 6 17.5 10 17.5z"
                        fill="#34A853"
                      />
                      <path
                        d="M4.2 9.2c-.2-.6-.3-1.4-.3-2.2 0-.8.1-1.6.3-2.2V2.4H.8C.1 3.8-.3 5.4-.3 7s.4 3.2 1.1 4.6l3.4-2.4z"
                        fill="#FBBC04"
                      />
                      <path
                        d="M10 3.8c1.5 0 2.8.5 3.9 1.5l2.9-2.9C15 1 12.7 0 10 0 6 0 2.5 2.4.8 5.8l3.4 2.4c.8-2.5 3.1-4.4 5.8-4.4z"
                        fill="#EA4335"
                      />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">
                      Express Checkout with Google Pay
                    </h4>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
                      Complete payment instantly using your saved Google account cards or biometric fingerprint/face verification.
                    </p>
                  </div>
                </div>

                {/* Google Pay Official Button */}
                <GooglePayButton
                  amount={order?.amount || 0}
                  currency={order?.currency || 'USD'}
                  isLoading={isProcessing}
                  onClick={handleGooglePayClick}
                />

                <div className="flex items-center justify-center gap-3 text-[11px] text-slate-400 pt-2">
                  <span>No card entry required</span>
                  <span>·</span>
                  <span>Instant confirmation</span>
                  <span>·</span>
                  <span>Zero fees</span>
                </div>
              </div>
            )}

            {/* Credit / Debit Card Tab Content */}
            {activePaymentMethod === 'card' && (
              <div className="space-y-6">
                {/* Interactive Virtual Card Preview */}
                <div className="pb-2">
                  <CardPreview
                    cardNumber={cardNumber}
                    cardName={cardName}
                    cardExpiry={cardExpiry}
                    brand={detectedBrand}
                  />
                </div>

                <form onSubmit={handleCardSubmit} className="space-y-4">
                  {/* Cardholder Name */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Name on Card
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. John Doe"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      className="w-full h-12 px-4 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900 transition-all font-sans"
                    />
                  </div>

                  {/* Card Number with Brand Recognition */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Card Number
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        placeholder="4242 ···· ···· 4242"
                        value={cardNumber}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, '').slice(0, 16);
                          setCardNumber(val.replace(/(\d{4})/g, '$1 ').trim());
                        }}
                        className="w-full h-12 px-4 pr-24 rounded-xl border border-slate-300 text-sm font-mono tracking-wider focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900 transition-all tabular-nums"
                      />
                      {/* Brand Icons in input */}
                      <div className="absolute right-3.5 top-3.5 flex items-center gap-1.5">
                        <img
                          src="https://js.stripe.com/v3/fingerprinted/img/visa-729c05c240c422b88b3979a9044ce4c6.svg"
                          alt="Visa"
                          className={`h-4 w-auto transition-opacity ${
                            detectedBrand === 'visa' || detectedBrand === 'generic'
                              ? 'opacity-100'
                              : 'opacity-25'
                          }`}
                        />
                        <img
                          src="https://js.stripe.com/v3/fingerprinted/img/mastercard-4d8844094130711885b5e41b28c9848f.svg"
                          alt="Mastercard"
                          className={`h-4 w-auto transition-opacity ${
                            detectedBrand === 'mastercard' || detectedBrand === 'generic'
                              ? 'opacity-100'
                              : 'opacity-25'
                          }`}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        Expiration Date
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="MM / YY"
                        maxLength={5}
                        value={cardExpiry}
                        onChange={(e) => {
                          let val = e.target.value.replace(/\D/g, '').slice(0, 4);
                          if (val.length >= 3) {
                            val = `${val.slice(0, 2)}/${val.slice(2)}`;
                          }
                          setCardExpiry(val);
                        }}
                        className="w-full h-12 px-4 rounded-xl border border-slate-300 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900 transition-all tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        Security Code (CVC)
                      </label>
                      <div className="relative">
                        <input
                          type="password"
                          required
                          placeholder="CVC"
                          maxLength={4}
                          value={cardCvc}
                          onChange={(e) =>
                            setCardCvc(e.target.value.replace(/\D/g, '').slice(0, 4))
                          }
                          className="w-full h-12 px-4 pr-10 rounded-xl border border-slate-300 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900 transition-all tabular-nums"
                        />
                        <Lock className="w-4 h-4 text-slate-400 absolute right-3.5 top-4 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  {/* Save Card Option */}
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="saveCardCheckbox"
                      checked={saveCard}
                      onChange={(e) => setSaveCard(e.target.checked)}
                      className="w-4 h-4 rounded text-slate-900 focus:ring-slate-900 border-slate-300 cursor-pointer"
                    />
                    <label
                      htmlFor="saveCardCheckbox"
                      className="text-xs text-slate-600 cursor-pointer select-none"
                    >
                      Save card securely for 1-click checkout on future orders
                    </label>
                  </div>

                  {/* Primary Pay Button */}
                  <div className="pt-3">
                    <button
                      type="submit"
                      disabled={isProcessing}
                      className="w-full h-13 bg-slate-950 hover:bg-black active:bg-slate-900 disabled:opacity-60 text-white font-bold rounded-2xl text-sm flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg cursor-pointer"
                    >
                      {isProcessing ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-white" />
                          <span>Authorizing Payment...</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4 text-emerald-400" />
                          <span>
                            Pay {order?.currency} {order?.amount.toFixed(2)} Securely
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Bottom Card Logos Strip */}
            <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Processed via Stripe & Google Pay Verified</span>
              </div>
              <div className="flex items-center gap-2.5 opacity-80">
                <span className="text-[10px] font-bold tracking-wider uppercase text-slate-400">
                  Accepted
                </span>
                <span className="font-semibold text-slate-600 text-xs">VISA</span>
                <span className="text-slate-300">·</span>
                <span className="font-semibold text-slate-600 text-xs">Mastercard</span>
                <span className="text-slate-300">·</span>
                <span className="font-semibold text-slate-600 text-xs">Amex</span>
                <span className="text-slate-300">·</span>
                <span className="font-semibold text-slate-600 text-xs">GPay</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
