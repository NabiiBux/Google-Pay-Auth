import React from 'react';

interface GooglePayButtonProps {
  amount: number;
  currency: string;
  onClick: () => void;
  isLoading: boolean;
  disabled?: boolean;
}

export const GooglePayButton: React.FC<GooglePayButtonProps> = ({
  amount,
  currency,
  onClick,
  isLoading,
  disabled = false,
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled || isLoading}
      aria-label="Pay with Google Pay"
      className="relative w-full h-12 bg-black hover:bg-neutral-900 active:bg-neutral-950 disabled:opacity-60 text-white font-medium rounded-lg flex items-center justify-center transition-all duration-150 shadow-xs cursor-pointer select-none"
    >
      {isLoading ? (
        <div className="flex items-center gap-2">
          <svg
            className="animate-spin h-5 w-5 text-white"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <span className="text-sm font-medium tracking-wide">Authorizing Google Pay...</span>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-neutral-300">Pay with</span>
          {/* Authentic Google Pay Logo SVG */}
          <div className="flex items-center gap-1">
            <svg
              className="h-5 w-auto"
              viewBox="0 0 41 17"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Google G */}
              <path
                d="M19.5 8.6c0-.6-.1-1.2-.2-1.7H10v3.4h5.3c-.2 1.2-.9 2.2-2 2.8v2.3h3.2c1.9-1.7 3-4.3 3-6.8z"
                fill="#4285F4"
              />
              <path
                d="M10 17.5c2.7 0 5-1 6.7-2.6l-3.2-2.3c-.9.6-2 .9-3.5.9-2.7 0-5-1.8-5.8-4.3H.8v2.4C2.5 15.1 6 17.5 10 17.5z"
                fill="#34A853"
              />
              <path
                d="M4.2 9.2c-.2-.6-.3-1.4-.3-2.2 0-.8.1-1.6.3-2.2V2.4H.8C.1 3.8-.3 5.4-.3 7s.4 3.2 1.1 4.6l3.4-2.4z"
                fill="#FBBC04"
              />
              <path
                d="M10 3.8c1.5 0 2.8.5 3.9 1.5l2.9-2.9C15 1 12.7 0 10 0 6 0 2.5 2.4.8 5.8l3.4 2.4c.8-2.5 3.1-4.4 5.8-4.4z"
                fill="#EA4335"
              />
              {/* "Pay" Text in Google Brand Style */}
              <path
                d="M26.2 3.5h-4.3v10.3h2.3V9.6h2c2.1 0 3.7-1.4 3.7-3.1 0-1.7-1.6-3-3.7-3zm0 4.1h-2v-2.1h2c1 0 1.6.5 1.6 1s-.6 1.1-1.6 1.1zm9.8 1.9c-.8 0-1.5.3-1.8.8v-.7h-2.2v7.7h2.3v-2.8c.4.4 1 .7 1.7.7 1.8 0 3.1-1.4 3.1-3.4s-1.3-3.3-3.1-3.3zm-.4 4.7c-1 0-1.7-.8-1.7-1.8s.7-1.8 1.7-1.8 1.7.8 1.7 1.8-.7 1.8-1.7 1.8zm9.3-3.3l-2.6 6.5h-2.3l1-2.2-2.5-5.7h2.4l1.3 3.6 1.3-3.6h2.4z"
                fill="#FFFFFF"
              />
            </svg>
          </div>
          <span className="text-xs text-neutral-400 font-mono ml-1 tabular-nums">
            ({currency} {amount.toFixed(2)})
          </span>
        </div>
      )}
    </button>
  );
};
