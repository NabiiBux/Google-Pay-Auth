import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { CheckoutPortal } from './components/CheckoutPortal';
import { IntegrationHub } from './components/IntegrationHub';

export default function App() {
  const [isMerchantMode, setIsMerchantMode] = useState(false);

  // If URL has ?merchant=true or ?admin=true, enable merchant tools
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('merchant') === 'true' || params.get('admin') === 'true') {
      setIsMerchantMode(true);
    }
  }, []);

  const handleReturnToStore = () => {
    const params = new URLSearchParams(window.location.search);
    const returnUrl = params.get('return_url');
    if (returnUrl) {
      window.location.href = returnUrl;
    } else {
      window.location.href = 'https://gnbmentor.com';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/60 flex flex-col font-sans text-slate-900 selection:bg-emerald-100 selection:text-emerald-900 antialiased">
      {/* Clean Top Navigation */}
      <Header
        onReturnToStore={handleReturnToStore}
        isMerchantMode={isMerchantMode}
        onToggleMerchantMode={() => setIsMerchantMode((prev) => !prev)}
      />

      {/* Main Experience */}
      <main className="flex-1">
        {isMerchantMode ? (
          <div className="py-6">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 mb-4 flex items-center justify-between">
              <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
                Merchant & Developer Console Active
              </span>
              <button
                onClick={() => setIsMerchantMode(false)}
                className="text-xs font-semibold text-slate-600 hover:text-slate-900 underline"
              >
                Switch back to Customer Checkout View
              </button>
            </div>
            <IntegrationHub
              initialTab="woocommerce"
              onNavigateToCheckoutWithUrl={() => setIsMerchantMode(false)}
            />
          </div>
        ) : (
          <CheckoutPortal />
        )}
      </main>

      {/* Restrained Luxury Footer */}
      <footer className="border-t border-slate-200/80 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} GNB Mentor.</span>
            <span aria-hidden="true">·</span>
            <span>All rights reserved.</span>
            <span aria-hidden="true">·</span>
            <a
              href="https://gnbmentor.com"
              className="text-slate-600 hover:text-slate-900 transition-colors"
            >
              gnbmentor.com
            </a>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-slate-600">Google Pay & Stripe Certified</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsMerchantMode(!isMerchantMode)}
              className="text-slate-400 hover:text-slate-700 transition-colors underline cursor-pointer"
            >
              {isMerchantMode ? 'View Customer Checkout' : 'Merchant Tools'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
