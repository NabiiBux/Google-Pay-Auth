import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import dotenv from 'dotenv';
import Stripe from 'stripe';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.resolve(__dirname, 'dist');
const hasDist = fs.existsSync(distPath);
const isProd = process.env.NODE_ENV === 'production' || hasDist;
const PORT = Number(process.env.PORT) || 3000;

const app = express();

// Capture raw body buffer for Stripe webhook verification
app.use(
  express.json({
    verify: (req: any, _res, buf) => {
      req.rawBody = buf;
    },
  })
);
app.use(express.urlencoded({ extended: true }));

// Initialize Stripe instance if secret key is present
const stripeSecretKey = process.env.STRIPE_SECRET_KEY || '';
const stripe = stripeSecretKey
  ? new Stripe(stripeSecretKey, {
      apiVersion: '2025-02-24.acacia' as any,
    })
  : null;

const HMAC_SECRET = process.env.HMAC_SECRET_KEY || 'gnbmentor_secure_default_secret_2026';
const WC_STORE_URL = process.env.WOOCOMMERCE_STORE_URL || 'https://gnbmentor.com';

/**
 * Utility: Compute HMAC SHA256 signature for order parameters
 * Payload format: "order_id|amount|currency|timestamp"
 */
function computeHmacSignature(
  orderId: string | number,
  amount: string | number,
  currency: string,
  timestamp: string | number,
  secret: string
): string {
  const normalizedAmount = Number(amount).toFixed(2);
  const payload = `${orderId}|${normalizedAmount}|${currency.toUpperCase()}|${timestamp}`;
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

/**
 * GET /api/health
 * Health check endpoint for AlmaLinux Nginx & PM2 probers
 */
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    service: 'pay.gnbmentor.com',
    stripeConfigured: Boolean(stripe),
    hasPublishableKey: Boolean(process.env.STRIPE_PUBLISHABLE_KEY),
  });
});

/**
 * GET /api/plugin-download
 * Download clean WooCommerce gateway plugin directly to WordPress
 */
app.get('/api/plugin-download', (_req, res) => {
  const pluginFile = path.resolve(__dirname, 'deploy', 'gnbmentor-wc-gateway.php');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.sendFile(pluginFile);
});

/**
 * GET /download/gnbmentor-pay.zip
 * Direct ZIP download for WP Admin > Plugins > Upload Plugin
 */
app.get('/download/gnbmentor-pay.zip', (_req, res) => {
  const zipFile = path.resolve(__dirname, 'public', 'gnbmentor-pay.zip');
  res.download(zipFile, 'gnbmentor-pay.zip');
});

/**
 * GET /api/config
 * Exposes non-sensitive client configuration
 */
app.get('/api/config', (_req, res) => {
  res.json({
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || '',
    storeDomain: WC_STORE_URL,
    isLive: Boolean(process.env.STRIPE_SECRET_KEY && !process.env.STRIPE_SECRET_KEY.startsWith('sk_test_')),
    isConfigured: Boolean(stripe),
  });
});

/**
 * POST /api/verify-signature
 * Validates HMAC integrity of incoming WooCommerce redirect parameters
 */
app.post('/api/verify-signature', (req, res) => {
  const { order_id, amount, currency, timestamp, signature } = req.body;

  if (!order_id || !amount || !currency || !timestamp || !signature) {
    return res.status(400).json({
      valid: false,
      error: 'Missing required parameters (order_id, amount, currency, timestamp, signature)',
    });
  }

  // Check timestamp staleness (e.g. 2 hours max expiry)
  const orderTime = Number(timestamp);
  const now = Math.floor(Date.now() / 1000);
  const maxAgeSeconds = 7200; // 2 hours

  if (isNaN(orderTime) || Math.abs(now - orderTime) > maxAgeSeconds) {
    return res.status(400).json({
      valid: false,
      error: 'Order link has expired or has an invalid timestamp. Please re-initiate checkout from gnbmentor.com.',
      isExpired: true,
    });
  }

  const expectedSignature = computeHmacSignature(
    order_id,
    amount,
    currency,
    timestamp,
    HMAC_SECRET
  );

  const isValid = crypto.timingSafeEqual(
    Buffer.from(signature, 'utf-8'),
    Buffer.from(expectedSignature, 'utf-8')
  );

  return res.json({
    valid: isValid,
    order_id,
    amount: Number(amount).toFixed(2),
    currency: currency.toUpperCase(),
  });
});

/**
 * POST /api/create-payment-intent
 * Creates a Stripe PaymentIntent with Google Pay & Card support
 */
app.post('/api/create-payment-intent', async (req, res) => {
  try {
    const {
      order_id,
      amount,
      currency = 'USD',
      customer_email,
      customer_name,
      order_key,
      signature,
      timestamp,
    } = req.body;

    if (!order_id || !amount) {
      return res.status(400).json({ error: 'order_id and amount are required' });
    }

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ error: 'Invalid order amount' });
    }

    // Convert to minor currency units (cents)
    const amountInCents = Math.round(numericAmount * 100);

    // If Stripe is configured with a real API key:
    if (stripe) {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency: currency.toLowerCase(),
        automatic_payment_methods: {
          enabled: true,
        },
        metadata: {
          order_id: String(order_id),
          order_key: String(order_key || ''),
          customer_name: String(customer_name || ''),
          customer_email: String(customer_email || ''),
          source: 'pay.gnbmentor.com',
          parent_domain: WC_STORE_URL,
        },
        receipt_email: customer_email || undefined,
        description: `GNB Mentor Order #${order_id}`,
      });

      return res.json({
        clientSecret: paymentIntent.client_secret,
        id: paymentIntent.id,
        amount: numericAmount,
        currency: currency.toUpperCase(),
        isMock: false,
      });
    }

    // Fallback: If Stripe API key is not yet set in .env on the server,
    // provide an emulated secure clientSecret response for preview and testing
    const mockIntentId = `pi_mock_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    return res.json({
      clientSecret: `${mockIntentId}_secret_test`,
      id: mockIntentId,
      amount: numericAmount,
      currency: currency.toUpperCase(),
      isMock: true,
      message: 'Running in sandbox simulation mode. Add STRIPE_SECRET_KEY to process real Stripe/GPay charges.',
    });
  } catch (error: any) {
    console.error('Error creating Stripe PaymentIntent:', error);
    return res.status(500).json({
      error: error.message || 'Failed to initialize payment',
    });
  }
});

/**
 * POST /api/webhook/stripe
 * Handles Stripe webhook notifications (payment_intent.succeeded, etc.)
 * Verifies signature and notifies WooCommerce on gnbmentor.com
 */
app.post('/api/webhook/stripe', async (req: any, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event | null = null;

  if (stripe && webhookSecret && sig && req.rawBody) {
    try {
      event = stripe.webhooks.constructEvent(req.rawBody, sig, webhookSecret);
    } catch (err: any) {
      console.error(`Webhook signature verification failed:`, err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
  } else {
    // If webhook secret isn't configured, parse the body directly in dev/testing
    event = req.body as Stripe.Event;
  }

  if (!event) {
    return res.status(400).json({ error: 'Invalid event payload' });
  }

  // Handle successful payments
  if (event.type === 'payment_intent.succeeded') {
    const paymentIntent = event.data.object as Stripe.PaymentIntent;
    const orderId = paymentIntent.metadata?.order_id;
    const orderKey = paymentIntent.metadata?.order_key;
    const customerEmail = paymentIntent.receipt_email || paymentIntent.metadata?.customer_email;

    console.log(`Payment confirmed for Order #${orderId} (${paymentIntent.id})`);

    // Notify WooCommerce store callback endpoint
    if (orderId) {
      try {
        const callbackUrl = `${WC_STORE_URL.replace(/\/$/, '')}/wp-json/gnbmentor-pay/v1/payment-callback`;
        const callbackPayload = {
          order_id: orderId,
          order_key: orderKey,
          transaction_id: paymentIntent.id,
          amount: (paymentIntent.amount / 100).toFixed(2),
          currency: paymentIntent.currency.toUpperCase(),
          status: 'completed',
          timestamp: Math.floor(Date.now() / 1000),
        };

        const callbackSignature = crypto
          .createHmac('sha256', HMAC_SECRET)
          .update(`${orderId}|${callbackPayload.transaction_id}|${callbackPayload.status}`)
          .digest('hex');

        // Optional non-blocking notification to WordPress
        fetch(callbackUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-GNB-Signature': callbackSignature,
          },
          body: JSON.stringify(callbackPayload),
        })
          .then((resp) => {
            console.log(`WooCommerce callback status: ${resp.status}`);
          })
          .catch((fetchErr) => {
            console.warn(`WooCommerce callback note: ${fetchErr.message}`);
          });
      } catch (err) {
        console.warn('Callback dispatch error:', err);
      }
    }
  }

  return res.json({ received: true, eventType: event.type });
});

/**
 * POST /api/simulate-woocommerce-order
 * Test helper to generate a cryptographically valid signed URL for testing
 */
app.post('/api/simulate-woocommerce-order', (req, res) => {
  const {
    order_id = String(Math.floor(1000 + Math.random() * 9000)),
    amount = '49.00',
    currency = 'USD',
    customer_name = 'Alex Morgan',
    customer_email = 'customer@example.com',
    order_key = `wc_order_${Math.random().toString(36).substring(2, 10)}`,
  } = req.body;

  const timestamp = Math.floor(Date.now() / 1000);
  const signature = computeHmacSignature(order_id, amount, currency, timestamp, HMAC_SECRET);

  const queryParams = new URLSearchParams({
    order_id: String(order_id),
    amount: String(amount),
    currency: String(currency),
    customer_name,
    customer_email,
    order_key,
    timestamp: String(timestamp),
    signature,
  });

  return res.json({
    order_id,
    amount,
    currency,
    timestamp,
    signature,
    redirectUrl: `/checkout?${queryParams.toString()}`,
    fullUrl: `https://pay.gnbmentor.com/checkout?${queryParams.toString()}`,
  });
});

// -------------------------------------------------------------
// Vite Frontend Middleware / Static Serve
// -------------------------------------------------------------
async function setupFrontend() {
  if (isProd) {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`> GNB Mentor Pay running on http://0.0.0.0:${PORT}`);
  });
}

setupFrontend().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
