// PM2 configuration for pay.gnbmentor.com on AlmaLinux VPS
// Usage: pm2 start deploy/ecosystem.config.cjs --env production

module.exports = {
  apps: [
    {
      name: 'gnbmentor-pay',
      script: 'npm',
      args: 'run start',
      cwd: '/var/www/pay.gnbmentor.com',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: '/var/log/pm2/gnbmentor-pay-err.log',
      out_file: '/var/log/pm2/gnbmentor-pay-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    },
  ],
};
